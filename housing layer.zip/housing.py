# OA3801 (Comp Methods II)
# Naval Postgraduate School
#
#   Austin McGahan
#
# This simple module includes a few support functions for housing layer.

import pandas as pd
import numpy as np

def build_bah_df(csvfile_bah_wo, csvfile_bah_w):
    #1. List of zip codes and MHAs (sorted_zipmha23.txt)
    sorted_zipmha23_df = pd.read_csv('sorted_zipmha23.txt', sep=" ", header=None, names=["zip_code", "mha"])
    
    #2. List of MHAs and MHA names (mhanames23.txt)
    mhanames23_df = pd.read_csv('mhanames23.txt', sep=";", header=None, names=["mha", "mha_names"])
    mhanames23_df.set_index('mha',inplace=True)
    mhanames23_list = mhanames23_df.index.values.tolist()
    
    #2a. Combine first two sources on mha
    zip_mha_names_df = pd.merge(sorted_zipmha23_df, mhanames23_df, on='mha')
    
    #3. 2023 BAH rates with dependents (bahwo23.txt)
    dbahwo23_df = pd.read_csv(csvfile_bah_wo, sep=',', names=['mha', 
                                      'EO1', 'EO2', 'EO3', 'EO4', 'EO5', 'EO6', 'EO7', 'EO8', 'EO9',
                                      'WO1','WO2','WO3','WO4','WO5', 'O01E', 'O02E', 'O03E',
                                      'O01','O02','O03','O04','O05','O06','O07','O08','O09', 'O010', 'dep_status'])
    dbahwo23_df['dep_status']='WO'
    
    #4. 2023 BAH rates with dependents (bahw23.txt):
    bahw23_df = pd.read_csv(csvfile_bah_w, sep=',', names=['mha', 
                                      'EO1', 'EO2', 'EO3', 'EO4', 'EO5', 'EO6', 'EO7','EO8','EO9',
                                      'WO1','WO2','WO3','WO4','WO5', 'O01E', 'O02E', 'O03E',
                                      'O01','O02','O03','O04','O05','O06','O07','O08','O09', 'O010', 'dep_status'])
    bahw23_df['dep_status']='W'
    bigtest = pd.concat([dbahwo23_df,bahw23_df])
    biggest_test = pd.merge(zip_mha_names_df, bigtest, on='mha')
    #display(zip_mha_names_df, bigtest,biggest_test)
    biggest_test.set_index('zip_code',inplace=True)
    return biggest_test

#def lookup_bah_rate(zip_code,dependent_status, rank):
    #dependent_df = biggest_test[biggest_test['dep_status'] == dependent_status] #filter BAH rates by dependent status
    #mil_housing_area = dependent_df.loc[zip_code, 'mha_names'] #look up housing area by zip code and mha names column
    #BAH = dependent_df.loc[zip_code, rank] #look up BAH rate by zip code and rank
    #return BAH, mil_housing_area, zip_code, dependent_status, rank

#Having trouble getting this function to run from housing.py. No issues running directly in notebook
def lookup_bah_rate(zip_code,dependent_status, rank):
    dependent_df = bah_rates[bah_rates['dep_status'] == dependent_status] #filter BAH rates by dependent status
    mil_housing_area = dependent_df.loc[zip_code, 'mha_names'] #look up housing area by zip code and mha names column
    BAH = dependent_df.loc[zip_code, rank] #look up BAH rate by zip code and rank
    return BAH, mil_housing_area, zip_code, dependent_status, rank

def build_fmr_df(xlsxfile_fy_safmrs):
    fmr_data_df = pd.read_excel(xlsxfile_fy_safmrs, index_col=0)
    return fmr_data_df

def build_mhp_df(csvfile_RDC_ZIP):
    mhp_df = pd.read_csv(csvfile_RDC_ZIP)
    mhp_df.set_index('postal_code',inplace=True)
    return mhp_df

def def lookup_fmr(zip_code):
    FMR0 = fmr_data_df.loc[zip_code, 'SAFMR\n0BR']
    FMR1 = fmr_data_df.loc[zip_code, 'SAFMR\n1BR']
    FMR2 = fmr_data_df.loc[zip_code, 'SAFMR\n2BR']
    FMR3 = fmr_data_df.loc[zip_code, 'SAFMR\n3BR']
    FMR4 = fmr_data_df.loc[zip_code, 'SAFMR\n4BR']
    hud_fmr_area = fmr_data_df.loc[zip_code, 'HUD Metro Fair Market Rent Area Name']
    return print('Fair Market Rent for: HUD Metro FMR Area:', 
                 hud_fmr_area, '(', zip_code, ')', 
                 ': 0 Bdrm: $', FMR0, 
                 ', 1 Bdrm: $', FMR1,  
                 ', 2 Bdrm: $', FMR2, 
                 ', 3 Bdrm: $', FMR3, 
                 ', 4 Bdrm: $', FMR4) 
